import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';

class HeartRateMonitorPage extends StatefulWidget {
  @override
  _HeartRateMonitorPageState createState() => _HeartRateMonitorPageState();
}

class _HeartRateMonitorPageState extends State<HeartRateMonitorPage> {
  double bpm = 0.0;
  bool fearDetected = false;
  Timer? _timer;

  // ⚠️ IMPORTANT: Update this path to your actual JSON file location
  final String filePath = 'C:\safe_space\bpm_output.json';

  @override
  void initState() {
    super.initState();
    _startMonitoring();
  }

  void _startMonitoring() {
    final file = File(filePath);

    _timer = Timer.periodic(Duration(seconds: 1), (_) async {
      if (await file.exists()) {
        try {
          final contents = await file.readAsString();
          final data = jsonDecode(contents);

          print("📥 JSON Read: $data");

          setState(() {
            bpm = (data['bpm'] as num).toDouble();
            fearDetected = data['fear'] as bool;
          });
        } catch (e) {
          print("⚠️ JSON read error: $e");
        }
      } else {
        print("❌ File not found at: $filePath");
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Heart Rate Monitor")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Current BPM", style: TextStyle(fontSize: 24)),
            SizedBox(height: 10),
            Text(bpm.toStringAsFixed(1),
                style: TextStyle(fontSize: 48, color: Colors.red)),
            SizedBox(height: 30),
            Text(
              fearDetected ? "⚠️ Fear Detected!" : "Status: Normal",
              style: TextStyle(
                  fontSize: 24,
                  color: fearDetected ? Colors.orange : Colors.green),
            ),
            SizedBox(height: 40),
            Text("Debug Info:", style: TextStyle(fontSize: 16)),
            Text("File Path: $filePath", style: TextStyle(fontSize: 12)),
            Text("BPM: $bpm | Fear: $fearDetected", style: TextStyle(fontSize: 14)),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';

/// Global list to hold all forum posts
List<Map<String, String>> forumPosts = [
  {
    'name': 'Ananya',
    'story': 'I faced a scary situation while returning home from work late at night...'
  },
  {
    'name': 'Ritika',
    'story': 'I want to raise awareness about a harassment incident that happened near the market...'
  },
];

/// Function to add experience
void addExperience(String name, String story) {
  forumPosts.add({'name': name, 'story': story});
}

class SafetyForumPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Safety Forum')),
      body: ListView.builder(
        padding: EdgeInsets.all(16),
        itemCount: forumPosts.length,
        itemBuilder: (context, index) {
          final post = forumPosts[index];
          return Card(
            elevation: 4,
            margin: EdgeInsets.symmetric(vertical: 8),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(post['name'] ?? '', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  SizedBox(height: 8),
                  Text(post['story'] ?? ''),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

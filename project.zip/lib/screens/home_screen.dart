import 'package:flutter/material.dart';
import 'forum_page.dart';
import 'enter_experience_page.dart';
import 'gps_tracker_page.dart';
import 'heart_rate_monitor_page.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("SafeSpace")),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "Welcome to SafeSpace!",
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 40),

              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => SafetyForumPage()),
                  );
                },
                child: Text("Safety Forum"),
              ),

              SizedBox(height: 20),

              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => EnterExperiencePage()),
                  );
                },
                child: Text("Enter Your Experience"),
              ),

              SizedBox(height: 20),

              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => GpsTrackerPage()),
                  );
                },
                child: Text("GPS Tracker"),
              ),

              SizedBox(height: 40),
              
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => HeartRateMonitorPage()),
                  );
                },
                child: Text("Heart Rate Monitor"),
              ),

            ],
          ),
        ),
      ),
    );
  }
}

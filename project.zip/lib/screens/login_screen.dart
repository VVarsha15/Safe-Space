import 'package:flutter/material.dart';
import 'signup_screen.dart';
import 'home_screen.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final phoneController = TextEditingController();
  final passwordController = TextEditingController();

  final _users = <String, String>{
    '9876543210': 'password123' // Dummy user
  };

  void _login() {
    final phone = phoneController.text;
    final pass = passwordController.text;

    if (_users.containsKey(phone)) {
      if (_users[phone] == pass) {
        Navigator.push(
            context, MaterialPageRoute(builder: (_) => HomeScreen()));
      } else {
        _showDialog("Incorrect password.");
      }
    } else {
      _showDialog("Invalid user, please sign up.");
    }
  }

  void _showDialog(String message) {
    showDialog(
        context: context,
        builder: (_) => AlertDialog(
              title: Text("Login Error"),
              content: Text(message),
              actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text("OK"))],
            ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Login")),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            TextField(controller: phoneController, keyboardType: TextInputType.phone, decoration: InputDecoration(labelText: "Phone Number")),
            SizedBox(height: 12),
            TextField(controller: passwordController, obscureText: true, decoration: InputDecoration(labelText: "Password")),
            SizedBox(height: 24),
            ElevatedButton(onPressed: _login, child: Text("Login")),
            TextButton(
              child: Text("Don't have an account? Sign Up"),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SignupScreen())),
            )
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'forum_page.dart'; // Make sure this is the correct path

class EnterExperiencePage extends StatefulWidget {
  @override
  _EnterExperiencePageState createState() => _EnterExperiencePageState();
}

class _EnterExperiencePageState extends State<EnterExperiencePage> {
  final nameController = TextEditingController();
  final storyController = TextEditingController();

  void _submitStory() {
    final name = nameController.text.trim();
    final story = storyController.text.trim();

    if (name.isEmpty || story.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Please fill in both fields.')));
      return;
    }

    addExperience(name, story); // Now it works!

    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Your story has been published.')));
    Navigator.pop(context); // Go back to Home or Forum
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Share Your Experience")),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            TextField(
              controller: nameController,
              decoration: InputDecoration(
                labelText: "Your Name",
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),
            Expanded(
              child: TextField(
                controller: storyController,
                decoration: InputDecoration(
                  labelText: "Describe your experience",
                  border: OutlineInputBorder(),
                  alignLabelWithHint: true,
                ),
                maxLines: null,
                expands: true,
                keyboardType: TextInputType.multiline,
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(onPressed: _submitStory, child: Text("Publish")),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    nameController.dispose();
    storyController.dispose();
    super.dispose();
  }
}

import 'package:flutter/material.dart';
import 'home_screen.dart';

class SignupScreen extends StatefulWidget {
  @override
  _SignupScreenState createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final _formKey = GlobalKey<FormState>();

  final nameController = TextEditingController();
  final phoneController = TextEditingController();
  final ageController = TextEditingController();
  final passwordController = TextEditingController();
  final emergencyNameController = TextEditingController();
  final emergencyPhoneController = TextEditingController();

  String? _relation;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Sign Up")),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildTextField(controller: nameController, label: "Name", validatorMsg: "Enter your name"),
              SizedBox(height: 15),
              _buildTextField(controller: phoneController, label: "Phone Number", keyboardType: TextInputType.phone, validatorMsg: "Enter your phone number"),
              SizedBox(height: 15),
              _buildTextField(
                controller: ageController,
                label: "Age",
                keyboardType: TextInputType.number,
                validator: (val) {
                  if (val == null || val.isEmpty) return "Enter your age";
                  if (int.tryParse(val) == null) return "Enter a valid number";
                  return null;
                },
              ),
              SizedBox(height: 15),
              _buildTextField(controller: passwordController, label: "Password", obscureText: true, validatorMsg: "Enter your password"),
              SizedBox(height: 15),
              _buildTextField(controller: emergencyNameController, label: "Emergency Contact Name", validatorMsg: "Enter emergency contact name"),
              SizedBox(height: 15),
              DropdownButtonFormField<String>(
                value: _relation,
                decoration: InputDecoration(
                  labelText: "Emergency Contact Relation",
                  border: OutlineInputBorder(),
                ),
                items: ["Mother", "Father", "Guardian", "Friend", "Sibling", "Other"].map((relation) {
                  return DropdownMenuItem(value: relation, child: Text(relation));
                }).toList(),
                onChanged: (val) => setState(() => _relation = val),
                validator: (val) => val == null || val.isEmpty ? "Select relation" : null,
              ),
              SizedBox(height: 15),
              _buildTextField(controller: emergencyPhoneController, label: "Emergency Contact Phone", keyboardType: TextInputType.phone, validatorMsg: "Enter emergency contact phone"),
              SizedBox(height: 30),
              Center(
                child: ElevatedButton(
                  child: Text("Submit"),
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      // Handle storing data if needed
                      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => HomeScreen()));
                    }
                  },
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    String? validatorMsg,
    TextInputType keyboardType = TextInputType.text,
    bool obscureText = false,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      obscureText: obscureText,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(),
      ),
      validator: validator ??
          (val) {
            if (val == null || val.isEmpty) return validatorMsg ?? "Field is required";
            return null;
          },
    );
  }

  @override
  void dispose() {
    nameController.dispose();
    phoneController.dispose();
    ageController.dispose();
    passwordController.dispose();
    emergencyNameController.dispose();
    emergencyPhoneController.dispose();
    super.dispose();
  }
}

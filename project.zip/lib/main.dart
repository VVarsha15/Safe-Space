import 'package:flutter/material.dart';
import 'screens/login_screen.dart';

void main() {
  runApp(SafeSpaceApp());
}

class SafeSpaceApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SafeSpace',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.purple),
      home: LoginScreen(),
    );
  }
}
